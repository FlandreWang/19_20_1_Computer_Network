from socket import *

print("Hello World!")
